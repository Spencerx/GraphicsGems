// ******************************************************************
//
// Physically Correct Direct Lighting For Distribution Ray Tracing
//             by Changyaw Wang
//
// geometry_object.c
//
// ******************************************************************

#include "utility.h"

void geom_obj::select_visible_point(
               const point&,  // not used 
               const double,  // not used
               const double,  // not used			
               point&,        // not used
               double&)       // not used
{ }

