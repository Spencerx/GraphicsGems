#if 0
#include <iostream>
#include <math.h>

#include "global.h"

static list<int> li;

#endif